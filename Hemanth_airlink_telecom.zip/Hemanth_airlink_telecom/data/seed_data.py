from data.datastore import DATASTORE
from models.subscriber import Subscriber
from models.plan import Prepaid, Postpaid, DataPack


def load_seed_data():
    DATASTORE["plans"].clear()
    DATASTORE["subscribers"].clear()
    DATASTORE["connections"].clear()

    # Plans
    p1 = Prepaid("Smart Saver", 200)
    p1.plan_id = "PRE-101"
    p2 = Postpaid("Business Pro", 500)
    p2.plan_id = "POST-201"
    p3 = DataPack("NetMax 2GB/day", 300)
    p3.plan_id = "DATA-301"

    DATASTORE["plans"][p1.plan_id] = p1
    DATASTORE["plans"][p2.plan_id] = p2
    DATASTORE["plans"][p3.plan_id] = p3

    # Subscribers
    s1 = Subscriber("SUB01", "Karthik", 26, "", "AAD-4821-9034", 2000)
    s2 = Subscriber("SUB02", "Divya", 34, "", "AAD-7733-1268", 5000)
    s3 = Subscriber("SUB03", "Vimal", 16, "", None, 500)

    DATASTORE["subscribers"][s1.person_id] = s1
    DATASTORE["subscribers"][s2.person_id] = s2
    DATASTORE["subscribers"][s3.person_id] = s3

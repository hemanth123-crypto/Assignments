class Connection:
    _counter = 9000

    def __init__(self, subscriber, plan, months: int):
        Connection._counter += 1
        self.connection_id = Connection._counter
        self.subscriber = subscriber
        self.plan = plan
        self.months = int(months)
        self.amount_paid = plan.bill(months) + plan.activation_fee
        self.status = "ACTIVE"

    def __str__(self):
        return f"Receipt\nConnection: {self.connection_id}\nSubscriber: {self.subscriber.person_id}\nPlan: {self.plan.plan_id}\nMonths: {self.months}\nPaid: {self.amount_paid}\nStatus: {self.status}"

    def __del__(self):
        print(f"[ARCHIVE] Connection #{self.connection_id} closed")

from .person import Person


class Subscriber(Person):
    def __init__(self, subscriber_id: str, name: str, age: int, phone: str, id_proof: str, balance: int):
        super().__init__(subscriber_id, name, age, phone)
        self.id_proof = id_proof
        self.__balance = int(balance)

    def recharge(self, amount: int):
        if amount <= 0:
            raise ValueError("Recharge amount must be positive")
        self.__balance += int(amount)

    def deduct(self, amount: int):
        amount = int(amount)
        if amount <= self.__balance:
            self.__balance -= amount
            return True
        return False

    @property
    def balance(self):
        return self.__balance

    def __str__(self):
        return f"Subscriber({self.person_id}, {self.name}, balance={self.__balance})"

class Plan:
    company = "AirLink"
    id_prefix = "PLAN-"
    activation_fee = 0
    _counter = 100

    def __init__(self, name: str, monthly_price: int, data_per_day: int = 0):
        self.name = name
        self._monthly_price = None
        self.monthly_price = monthly_price
        self.data_per_day = data_per_day
        Plan._counter += 1
        self.plan_id = f"{self.id_prefix}{Plan._counter}"

    @property
    def monthly_price(self):
        return self._monthly_price

    @monthly_price.setter
    def monthly_price(self, value):
        if value <= 0:
            raise ValueError("monthly_price must be > 0")
        self._monthly_price = int(value)

    def bill(self, months: int):
        return self.monthly_price * int(months)

    def __eq__(self, other):
        if not isinstance(other, Plan):
            return NotImplemented
        return (self.plan_id == other.plan_id)

    def __lt__(self, other):
        return self.monthly_price < other.monthly_price

    def __str__(self):
        return f"{self.plan_id}: {self.name} @ {self.monthly_price}"


class Prepaid(Plan):
    id_prefix = "PRE-"
    activation_fee = 0

    def bill(self, months: int):
        return super().bill(months)


class Postpaid(Plan):
    id_prefix = "POST-"
    activation_fee = 100

    def bill(self, months: int):
        base = super().bill(months)
        return int(base * 1.18)


class DataPack(Plan):
    id_prefix = "DATA-"
    activation_fee = 50

    def bill(self, months: int):
        return super().bill(months) + 50

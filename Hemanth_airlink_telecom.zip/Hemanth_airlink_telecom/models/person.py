class Person:
    def __init__(self, person_id: str, name: str, age: int, phone: str):
        self.person_id = person_id
        self.name = name
        self.age = age
        self.phone = phone

    def __str__(self):
        return f"Person({self.person_id}, {self.name})"

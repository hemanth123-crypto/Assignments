import unittest
from data.datastore import DATASTORE
from data.seed_data import load_seed_data
from services.connection_service import ConnectionService


class TestConnection(unittest.TestCase):
    def setUp(self):
        DATASTORE["subscribers"].clear()
        DATASTORE["plans"].clear()
        DATASTORE["connections"].clear()
        load_seed_data()

    def test_activate_success(self):
        # SUB01 has 2000 balance, plan PRE-101 costs 200*2
        conn = ConnectionService.activate("SUB01", "PRE-101", 2)
        self.assertEqual(conn.status, "ACTIVE")
        self.assertIn(conn.connection_id, DATASTORE["connections"])

    def test_ineligible_blocked(self):
        with self.assertRaises(PermissionError):
            ConnectionService.activate("SUB03", "PRE-101", 1)


if __name__ == "__main__":
    unittest.main()

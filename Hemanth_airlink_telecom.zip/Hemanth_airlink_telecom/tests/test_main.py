import unittest

from data.datastore import DATASTORE
from main import add_plan_interactive, register_subscriber_interactive
from services.telecom_system import TelecomSystem


class TestMainCLI(unittest.TestCase):
    def setUp(self):
        DATASTORE["subscribers"].clear()

    def test_register_subscriber_from_prompt(self):
        system = TelecomSystem()
        inputs = iter(["SUB100", "Alice", "25", "9999999999", "ID-100", "1000"])
        outputs = []

        def fake_input(_prompt):
            return next(inputs)

        def fake_print(message):
            outputs.append(message)

        register_subscriber_interactive(system, fake_input, fake_print)

        self.assertIn("SUB100", DATASTORE["subscribers"])
        self.assertEqual(DATASTORE["subscribers"]["SUB100"].name, "Alice")
        self.assertEqual(outputs[-1], "Subscriber registered successfully.")

    def test_add_plan_from_prompt(self):
        system = TelecomSystem()
        inputs = iter(["prepaid", "Unlimited", "250", "5"])
        outputs = []

        def fake_input(_prompt):
            return next(inputs)

        def fake_print(message):
            outputs.append(message)

        add_plan_interactive(system, fake_input, fake_print)

        created_plan = next(plan for plan in DATASTORE["plans"].values() if plan.name == "Unlimited")
        self.assertEqual(len(DATASTORE["plans"]), 4)
        self.assertEqual(created_plan.name, "Unlimited")
        self.assertEqual(outputs[-1], "Plan added successfully.")


if __name__ == "__main__":
    unittest.main()

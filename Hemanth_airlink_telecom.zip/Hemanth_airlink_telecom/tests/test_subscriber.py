import unittest
from data.datastore import DATASTORE
from models.subscriber import Subscriber


class TestSubscriber(unittest.TestCase):
    def setUp(self):
        DATASTORE["subscribers"].clear()

    def test_add_subscriber(self):
        s = Subscriber("SUB10", "Test", 30, "", "ID-1", 1000)
        DATASTORE["subscribers"][s.person_id] = s
        self.assertIn("SUB10", DATASTORE["subscribers"])

    def test_balance_encapsulation(self):
        s = Subscriber("SUB11", "Test2", 25, "", "ID-2", 100)
        self.assertFalse(s.deduct(200))
        with self.assertRaises(AttributeError):
            _ = s.__balance


if __name__ == "__main__":
    unittest.main()

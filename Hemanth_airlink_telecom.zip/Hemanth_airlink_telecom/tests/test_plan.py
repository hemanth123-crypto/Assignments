import unittest
from models.plan import Prepaid, Postpaid, DataPack
from data.datastore import DATASTORE


class TestPlan(unittest.TestCase):
    def setUp(self):
        DATASTORE["plans"].clear()

    def test_bill_overriding(self):
        p1 = Prepaid("P", 200)
        p2 = Postpaid("P2", 500)
        p3 = DataPack("P3", 300)
        self.assertEqual(p1.bill(2), 400)
        self.assertEqual(p2.bill(2), 1180)
        self.assertEqual(p3.bill(2), 650)

    def test_price_validation(self):
        with self.assertRaises(ValueError):
            Prepaid("Bad", 0)


if __name__ == "__main__":
    unittest.main()

from data.seed_data import load_seed_data
from services.subscriber_service import SubscriberService
from services.plan_service import PlanService
from services.connection_service import ConnectionService


class TelecomSystem:
    def __init__(self):
        load_seed_data()

    def register_subscriber(self, subscriber):
        SubscriberService.add_subscriber(subscriber)

    def add_plan(self, plan):
        PlanService.add_plan(plan)

    def view_plans(self):
        return sorted(PlanService.list_plans())

    def activate(self, sub_id, plan_id, months):
        return ConnectionService.activate(sub_id, plan_id, months)

    def deactivate(self, conn_id, used_months, port_out=False):
        return ConnectionService.deactivate(conn_id, used_months, port_out)

    def view_connections(self):
        return ConnectionService.list_connections()

from data.datastore import DATASTORE
from models.subscriber import Subscriber


class SubscriberService:
    @staticmethod
    def add_subscriber(subscriber: Subscriber):
        DATASTORE["subscribers"][subscriber.person_id] = subscriber

    @staticmethod
    def get_subscriber(sub_id):
        return DATASTORE["subscribers"].get(sub_id)

    @staticmethod
    def list_subscribers():
        return list(DATASTORE["subscribers"].values())

    @staticmethod
    def update_phone(sub_id, phone):
        s = SubscriberService.get_subscriber(sub_id)
        if s:
            s.phone = phone
            return True
        return False

    @staticmethod
    def delete_subscriber(sub_id):
        return DATASTORE["subscribers"].pop(sub_id, None)

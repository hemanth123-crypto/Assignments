from data.datastore import DATASTORE


class PlanService:
    @staticmethod
    def add_plan(plan):
        DATASTORE["plans"][plan.plan_id] = plan

    @staticmethod
    def get_plan(plan_id):
        return DATASTORE["plans"].get(plan_id)

    @staticmethod
    def list_plans():
        return list(DATASTORE["plans"].values())

    @staticmethod
    def apply_festival_offer(plan_id, pct):
        p = PlanService.get_plan(plan_id)
        if p:
            setattr(p, "festival_offer", float(pct) / 100.0)
            return True
        return False

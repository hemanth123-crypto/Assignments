from data.datastore import DATASTORE
from models.connection import Connection
from services.subscriber_service import SubscriberService
from services.plan_service import PlanService
from utils.validator import is_eligible, has_active_connection


class ConnectionService:
    @staticmethod
    def activate(sub_id, plan_id, months):
        sub = SubscriberService.get_subscriber(sub_id)
        plan = PlanService.get_plan(plan_id)
        if not sub or not plan:
            raise ValueError("Invalid subscriber or plan")
        if not is_eligible(sub):
            raise PermissionError("Subscriber not eligible")
        if has_active_connection(sub.person_id):
            raise RuntimeError("Subscriber already has an active connection")

        total = plan.bill(months) + plan.activation_fee
        # festival offer
        offer = getattr(plan, "festival_offer", 0)
        if offer:
            total = int(total * (1 - offer))

        if not sub.deduct(total):
            raise RuntimeError("Insufficient balance")

        conn = Connection(sub, plan, months)
        conn.amount_paid = total
        DATASTORE["connections"][conn.connection_id] = conn
        return conn

    @staticmethod
    def deactivate(conn_id, used_months, port_out=False):
        conn = DATASTORE["connections"].get(conn_id)
        if not conn:
            raise ValueError("Connection not found")
        if conn.status != "ACTIVE":
            return conn

        remaining = max(0, conn.months - int(used_months))
        refund = 0
        if remaining > 0:
            refund = int(remaining * conn.plan.monthly_price * 0.5)
            if port_out:
                refund = max(0, refund - 150)

        if refund > 0:
            conn.subscriber.recharge(refund)

        conn.status = "DEACTIVATED"
        if port_out:
            setattr(conn, "port_out_note", True)
        return conn

    @staticmethod
    def get_connection(conn_id):
        return DATASTORE["connections"].get(conn_id)

    @staticmethod
    def list_connections():
        return list(DATASTORE["connections"].values())

    @staticmethod
    def delete_connection(conn_id):
        return DATASTORE["connections"].pop(conn_id, None)

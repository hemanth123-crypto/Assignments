"""AirLink Telecom package."""

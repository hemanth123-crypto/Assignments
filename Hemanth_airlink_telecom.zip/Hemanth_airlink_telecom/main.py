from services.telecom_system import TelecomSystem


def menu():
    print("\n======= AIRLINK TELECOM PORTAL =======")
    print(" 1. Register subscriber")
    print(" 2. Add plan")
    print(" 3. View plans (sorted by price)")
    print(" 4. Activate a connection")
    print(" 5. Deactivate a connection")
    print(" 6. View connections")
    print(" 7. Exit (archive connections -> destructors fire)")


def main():
    system = TelecomSystem()
    while True:
        menu()
        choice = input("Enter choice: ")
        if choice == "1":
            print("Use services directly or tests to add subscribers.")
        elif choice == "2":
            print("Use services directly or tests to add plans.")
        elif choice == "3":
            for p in system.view_plans():
                print(p)
        elif choice == "4":
            sub = input("Subscriber ID: ")
            plan = input("Plan ID: ")
            months = int(input("Months: "))
            try:
                conn = system.activate(sub, plan, months)
                print(conn)
            except Exception as e:
                print("Error:", e)
        elif choice == "5":
            cid = int(input("Connection ID: "))
            used = int(input("Used months: "))
            port = input("Port out (y/n): ") == "y"
            conn = system.deactivate(cid, used, port)
            print(conn)
        elif choice == "6":
            for c in system.view_connections():
                print(c)
        elif choice == "7":
            print("Exiting and archiving connections")
            break
        else:
            print("Invalid choice")


if __name__ == "__main__":
    main()

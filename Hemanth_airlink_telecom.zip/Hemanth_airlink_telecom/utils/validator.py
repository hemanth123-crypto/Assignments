from data.datastore import DATASTORE


def is_eligible(subscriber) -> bool:
    return subscriber.age >= 18 and bool(subscriber.id_proof)


def has_active_connection(subscriber_id) -> bool:
    for c in DATASTORE["connections"].values():
        if c.subscriber.person_id == subscriber_id and c.status == "ACTIVE":
            return True
    return False


def positive_int(value) -> bool:
    try:
        return int(value) > 0
    except Exception:
        return False

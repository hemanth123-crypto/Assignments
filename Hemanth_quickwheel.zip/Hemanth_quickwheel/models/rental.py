class Rental:
    rental_counter = 5000

    def __init__(self, customer, vehicle, planned_days, amount_paid, deposit, status="ACTIVE"):
        Rental.rental_counter += 1
        self.rental_id = Rental.rental_counter
        self.customer = customer
        self.vehicle = vehicle
        self.planned_days = planned_days
        self.amount_paid = amount_paid
        self.deposit = deposit
        self.status = status
        self.damage_note = None

    def __str__(self):
        return f"Rental #{self.rental_id} - {self.customer.name} -> {self.vehicle.name}"

    def __del__(self):
        if getattr(self, "_archived", False):
            return
        print(f"[ARCHIVE] Rental #{self.rental_id} closed")

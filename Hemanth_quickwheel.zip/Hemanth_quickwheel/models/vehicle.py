class Vehicle:
    company = "QuickWheels"
    id_prefix = "V-"
    deposit_days = 0
    _id_counter = 0

    def __init__(self, name_or_rate, daily_rate=None, vehicle_id=None):
        if daily_rate is None:
            name = self.__class__.__name__
            rate = name_or_rate
        else:
            name = name_or_rate
            rate = daily_rate

        if rate <= 0:
            raise ValueError("daily_rate must be positive")
        self.__class__._id_counter += 1
        self.vehicle_id = vehicle_id or f"{self.id_prefix}{self.__class__._id_counter:03d}"
        self.name = name
        self.available = True
        self._daily_rate = rate

    @property
    def daily_rate(self):
        return self._daily_rate

    @daily_rate.setter
    def daily_rate(self, value):
        if value <= 0:
            raise ValueError("daily_rate must be positive")
        self._daily_rate = value

    def rental_cost(self, days):
        return self.daily_rate * days

    def __eq__(self, other):
        return isinstance(other, Vehicle) and self.vehicle_id == other.vehicle_id

    def __lt__(self, other):
        return self.daily_rate < other.daily_rate

    def __str__(self):
        return f"{self.name} ({self.vehicle_id})"


class Bike(Vehicle):
    id_prefix = "B-"
    deposit_days = 1

    def rental_cost(self, days):
        return self.daily_rate * days


class Car(Vehicle):
    id_prefix = "C-"
    deposit_days = 2

    def rental_cost(self, days):
        return self.daily_rate * days * 1.05


class SUV(Vehicle):
    id_prefix = "S-"
    deposit_days = 3

    def rental_cost(self, days):
        return self.daily_rate * days + 500

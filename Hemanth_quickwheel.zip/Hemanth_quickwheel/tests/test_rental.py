import unittest

from data.datastore import DATASTORE, clear_datastore
from services.customer_service import CustomerService
from services.rental_service import RentalService
from services.vehicle_service import VehicleService


class RentalTests(unittest.TestCase):
    def setUp(self):
        clear_datastore()

    def test_rent_success(self):
        customer_service = CustomerService()
        vehicle_service = VehicleService()
        rental_service = RentalService()

        customer = customer_service.add_customer("Arjun", 24, "9999999999", "TN10-2021-0042", 5000)
        vehicle = vehicle_service.add_vehicle("Bike", "Honda Activa", 400)

        rental = rental_service.rent(customer.person_id, vehicle.vehicle_id, 2)

        self.assertIsNotNone(rental)
        self.assertFalse(vehicle.available)
        self.assertEqual(customer.balance, 3800)
        self.assertIn(rental.rental_id, DATASTORE["rentals"])

    def test_ineligible_blocked(self):
        customer_service = CustomerService()
        vehicle_service = VehicleService()
        rental_service = RentalService()

        customer = customer_service.add_customer("Rahul", 17, "9999999999", "", 2000)
        vehicle = vehicle_service.add_vehicle("Bike", "Honda Activa", 400)

        rental = rental_service.rent(customer.person_id, vehicle.vehicle_id, 2)

        self.assertIsNone(rental)
        self.assertEqual(DATASTORE["rentals"], {})

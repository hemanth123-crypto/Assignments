import unittest

from data.datastore import DATASTORE, clear_datastore
from models.customer import Customer
from services.customer_service import CustomerService


class CustomerTests(unittest.TestCase):
    def setUp(self):
        clear_datastore()

    def test_add_customer(self):
        service = CustomerService()
        customer = service.add_customer("Arjun", 24, "9999999999", "TN10-2021-0042", 5000)

        self.assertIn(customer.person_id, DATASTORE["customers"])
        self.assertEqual(DATASTORE["customers"][customer.person_id].name, "Arjun")

    def test_wallet_encapsulation(self):
        customer = Customer("CU01", "Arjun", 24, "9999999999", "TN10-2021-0042", 5000)

        self.assertFalse(customer.pay(6000))
        self.assertEqual(customer.balance, 5000)

        with self.assertRaises(AttributeError):
            _ = customer.__wallet

import unittest

from models.vehicle import Bike, Car, SUV
from data.datastore import clear_datastore


class VehicleTests(unittest.TestCase):
    def setUp(self):
        clear_datastore()

    def test_rental_cost_overriding(self):
        self.assertEqual(Bike(400).rental_cost(2), 800)
        self.assertEqual(Car(1800).rental_cost(2), 3780)
        self.assertEqual(SUV(3500).rental_cost(2), 7500)

    def test_rate_validation(self):
        with self.assertRaises(ValueError):
            Bike(0)

        with self.assertRaises(ValueError):
            Car(-1)

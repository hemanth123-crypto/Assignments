from data.seed_data import seed_data
from services.customer_service import CustomerService
from services.rental_service import RentalService
from services.vehicle_service import VehicleService


class RentalSystem:
    def __init__(self):
        self.customer_service = CustomerService()
        self.vehicle_service = VehicleService()
        self.rental_service = RentalService()
        seed_data()

    def register_customer(self, name, age, phone, license_no, wallet):
        return self.customer_service.add_customer(name, age, phone, license_no, wallet)

    def add_vehicle(self, vehicle_type, name, daily_rate):
        return self.vehicle_service.add_vehicle(vehicle_type, name, daily_rate)

    def view_vehicles(self):
        return sorted(self.vehicle_service.list_vehicles(), key=lambda v: v.daily_rate)

    def rent_vehicle(self, customer_id, vehicle_id, days):
        return self.rental_service.rent(customer_id, vehicle_id, days)

    def return_vehicle(self, rental_id, actual_days, damage_note=None):
        return self.rental_service.return_vehicle(rental_id, actual_days, damage_note)

    def view_rentals(self):
        return self.rental_service.list_rentals()

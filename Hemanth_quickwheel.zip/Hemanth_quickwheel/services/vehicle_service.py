from data.datastore import DATASTORE
from models.vehicle import Bike, Car, SUV


class VehicleService:
    def add_vehicle(self, vehicle_type, name, daily_rate):
        vehicle_class = {"Bike": Bike, "Car": Car, "SUV": SUV}.get(vehicle_type)
        if not vehicle_class:
            raise ValueError("Unsupported vehicle type")
        vehicle = vehicle_class(name, daily_rate)
        DATASTORE["vehicles"][vehicle.vehicle_id] = vehicle
        return vehicle

    def get_vehicle(self, vehicle_id):
        return DATASTORE["vehicles"].get(vehicle_id)

    def list_vehicles(self):
        return list(DATASTORE["vehicles"].values())

    def update_vehicle(self, vehicle_id, daily_rate):
        vehicle = DATASTORE["vehicles"].get(vehicle_id)
        if vehicle:
            vehicle.daily_rate = daily_rate
            return vehicle
        return None

    def delete_vehicle(self, vehicle_id):
        return DATASTORE["vehicles"].pop(vehicle_id, None)

    def apply_festival_offer(self, vehicle_id, pct):
        vehicle = DATASTORE["vehicles"].get(vehicle_id)
        if vehicle:
            setattr(vehicle, "festival_offer", pct)
            return vehicle
        return None

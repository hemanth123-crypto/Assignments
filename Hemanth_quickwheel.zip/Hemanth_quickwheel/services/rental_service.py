from data.datastore import DATASTORE
from models.rental import Rental
from utils.validator import is_eligible, is_available


class RentalService:
    def rent(self, customer_id, vehicle_id, days):
        customer = DATASTORE["customers"].get(customer_id)
        vehicle = DATASTORE["vehicles"].get(vehicle_id)

        if not customer or not vehicle:
            return None
        if not is_eligible(customer) or not is_available(vehicle):
            return None

        rental_cost = vehicle.rental_cost(days)
        deposit = vehicle.daily_rate * vehicle.deposit_days
        total_charge = rental_cost + deposit

        if not customer.pay(total_charge):
            return None

        vehicle.available = False
        rental = Rental(customer, vehicle, days, rental_cost, deposit)
        DATASTORE["rentals"][rental.rental_id] = rental
        return rental

    def return_vehicle(self, rental_id, actual_days, damage_note=None):
        rental = DATASTORE["rentals"].get(rental_id)
        if not rental:
            return None

        extra_days = max(0, actual_days - rental.planned_days)
        late_fee = extra_days * rental.vehicle.daily_rate * 1.5
        damage_fine = 1000 if damage_note else 0
        charges = late_fee + damage_fine
        refund = max(0, rental.deposit - charges)
        rental.vehicle.available = True
        rental.status = "CLOSED"
        rental.damage_note = damage_note
        rental._archived = True
        return {"rental": rental, "refund": refund}

    def get_rental(self, rental_id):
        return DATASTORE["rentals"].get(rental_id)

    def list_rentals(self):
        return list(DATASTORE["rentals"].values())

    def delete_rental(self, rental_id):
        return DATASTORE["rentals"].pop(rental_id, None)

from data.datastore import DATASTORE
from models.customer import Customer


class CustomerService:
    def add_customer(self, name, age, phone, license_no, wallet):
        customer_id = f"CU{len(DATASTORE['customers']) + 1:02d}"
        customer = Customer(customer_id, name, age, phone, license_no, wallet)
        DATASTORE["customers"][customer.person_id] = customer
        return customer

    def get_customer(self, customer_id):
        return DATASTORE["customers"].get(customer_id)

    def list_customers(self):
        return list(DATASTORE["customers"].values())

    def update_phone(self, customer_id, phone):
        customer = DATASTORE["customers"].get(customer_id)
        if customer:
            customer.phone = phone
            return customer
        return None

    def delete_customer(self, customer_id):
        return DATASTORE["customers"].pop(customer_id, None)

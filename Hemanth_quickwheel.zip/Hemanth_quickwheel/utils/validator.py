def is_eligible(customer):
    return customer.age >= 18 and bool(customer.license_no)


def is_available(vehicle):
    return vehicle.available


def positive_int(value):
    return isinstance(value, int) and value > 0

from models.customer import Customer
from models.vehicle import Bike, Car, SUV
from data.datastore import DATASTORE


def seed_data():
    if DATASTORE["customers"] or DATASTORE["vehicles"] or DATASTORE["rentals"]:
        return

    customer1 = Customer("CU01", "Arjun", 24, "9999999999", "TN10-2021-0042", 5000)
    customer2 = Customer("CU02", "Meera", 31, "8888888888", "TN22-2018-0913", 15000)
    customer3 = Customer("CU03", "Rahul", 17, "7777777777", "", 2000)

    DATASTORE["customers"][customer1.person_id] = customer1
    DATASTORE["customers"][customer2.person_id] = customer2
    DATASTORE["customers"][customer3.person_id] = customer3

    vehicle1 = Bike("Honda Activa", 400)
    vehicle2 = Car("Maruti Swift", 1800)
    vehicle3 = SUV("Toyota Innova", 3500)

    DATASTORE["vehicles"][vehicle1.vehicle_id] = vehicle1
    DATASTORE["vehicles"][vehicle2.vehicle_id] = vehicle2
    DATASTORE["vehicles"][vehicle3.vehicle_id] = vehicle3

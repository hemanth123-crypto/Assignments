DATASTORE = {
    "customers": {},
    "vehicles": {},
    "rentals": {},
}


def clear_datastore():
    DATASTORE["customers"].clear()
    DATASTORE["vehicles"].clear()
    DATASTORE["rentals"].clear()

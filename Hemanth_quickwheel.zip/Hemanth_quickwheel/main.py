from services.rental_system import RentalSystem


def main():
    system = RentalSystem()
    while True:
        print("\n====== QUICKWHEELS VEHICLE RENTAL ======")
        print(" 1. Register customer")
        print(" 2. Add vehicle")
        print(" 3. View vehicles (sorted by rate)")
        print(" 4. Rent a vehicle")
        print(" 5. Return a vehicle")
        print(" 6. View rentals")
        print(" 7. Exit (archive rentals -> destructors fire)")

        choice = input("Enter your choice: ").strip()
        if choice == "1":
            name = input("Name: ")
            age = int(input("Age: "))
            phone = input("Phone: ")
            license_no = input("License number: ")
            wallet = int(input("Wallet amount: "))
            system.register_customer(name, age, phone, license_no, wallet)
        elif choice == "2":
            vehicle_type = input("Vehicle type (Bike/Car/SUV): ")
            name = input("Vehicle name: ")
            rate = int(input("Daily rate: "))
            system.add_vehicle(vehicle_type, name, rate)
        elif choice == "3":
            for vehicle in system.view_vehicles():
                print(vehicle)
        elif choice == "4":
            customer_id = input("Customer ID: ")
            vehicle_id = input("Vehicle ID: ")
            days = int(input("Days: "))
            rental = system.rent_vehicle(customer_id, vehicle_id, days)
            if rental:
                print("Rental created")
            else:
                print("Rental denied")
        elif choice == "5":
            rental_id = int(input("Rental ID: "))
            actual_days = int(input("Actual days: "))
            result = system.return_vehicle(rental_id, actual_days)
            if result:
                print("Vehicle returned")
        elif choice == "6":
            for rental in system.view_rentals():
                print(rental)
        elif choice == "7":
            break
        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()

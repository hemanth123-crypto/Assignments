import os
from datetime import datetime
from typing import Optional

from dotenv import load_dotenv
from sqlalchemy import Column, DateTime, Integer, String, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

load_dotenv()

Base = declarative_base()


def _build_engine():
    database_url = os.getenv("AZURE_SQL_CONNECTION_STRING", "").strip()
    if database_url:
        try:
            return create_engine(database_url, echo=False)
        except Exception:
            pass
    return create_engine("sqlite:///./documents.db", echo=False)


class Document(Base):
    __tablename__ = "documents"

    document_id = Column(Integer, primary_key=True, index=True)
    file_name = Column(String(255), nullable=False)
    blob_url = Column(String(1000), nullable=False)
    uploaded_by = Column(String(255), nullable=False)
    upload_date = Column(DateTime, default=datetime.utcnow, nullable=False)
    file_type = Column(String(50), nullable=False)

engine = _build_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def add_document(file_name: str, blob_url: str, uploaded_by: str, file_type: str) -> Document:
    db = SessionLocal()
    try:
        document = Document(file_name=file_name, blob_url=blob_url, uploaded_by=uploaded_by, file_type=file_type)
        db.add(document)
        db.commit()
        db.refresh(document)
        return document
    finally:
        db.close()


def get_all_documents():
    db = SessionLocal()
    try:
        return db.query(Document).order_by(Document.document_id.desc()).all()
    finally:
        db.close()


def get_document_by_id(document_id: int) -> Optional[Document]:
    db = SessionLocal()
    try:
        return db.query(Document).filter(Document.document_id == document_id).first()
    finally:
        db.close()


def delete_document_by_id(document_id: int):
    db = SessionLocal()
    try:
        doc = db.query(Document).filter(Document.document_id == document_id).first()
        if doc:
            db.delete(doc)
            db.commit()
    finally:
        db.close()

import os
from typing import List

from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, RedirectResponse, Response
from pydantic import BaseModel

load_dotenv()

app = FastAPI(title="Smart Document Management System")

class DocumentMetadata(BaseModel):
    document_id: int
    file_name: str
    blob_url: str
    uploaded_by: str
    upload_date: str
    file_type: str

class ShareLinkRequest(BaseModel):
    expiry_hours: int

class ShareLinkResponse(BaseModel):
    document_id: int
    sas_url: str
    expires_in_hours: int

@app.get("/")
def root():
    return RedirectResponse(url="/docs")

@app.get("/health")
def health_check():
    return {"status": "ok"}

@app.post("/documents/upload", response_model=DocumentMetadata)
def upload_document(file: UploadFile = File(...), uploaded_by: str = "anonymous"):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file uploaded")

    allowed_types = {"pdf", "png", "jpg", "jpeg", "doc", "docx", "txt"}
    extension = file.filename.split(".")[-1].lower()
    if extension not in allowed_types:
        raise HTTPException(status_code=400, detail="Unsupported file type")

    try:
        from blob import upload_blob, get_blob_url
        from database import init_db, add_document

        container_name = os.getenv("AZURE_CONTAINER_NAME", "documents")
        blob_name = f"{uploaded_by}/{file.filename}"
        blob_content = file.file.read()
        upload_result = upload_blob(container_name, blob_name, blob_content, content_type=file.content_type or "application/octet-stream")
        blob_url = upload_result if upload_result else get_blob_url(container_name, blob_name)

        init_db()
        doc = add_document(file_name=file.filename, blob_url=blob_url, uploaded_by=uploaded_by, file_type=extension)
        return DocumentMetadata(document_id=doc.document_id, file_name=doc.file_name, blob_url=doc.blob_url, uploaded_by=doc.uploaded_by, upload_date=doc.upload_date.isoformat(), file_type=doc.file_type)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@app.get("/documents", response_model=List[DocumentMetadata])
def list_documents():
    try:
        from database import get_all_documents
        docs = get_all_documents()
        return [DocumentMetadata(document_id=d.document_id, file_name=d.file_name, blob_url=d.blob_url, uploaded_by=d.uploaded_by, upload_date=d.upload_date.isoformat(), file_type=d.file_type) for d in docs]
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@app.get("/documents/{document_id}", response_model=DocumentMetadata)
def get_document(document_id: int):
    try:
        from database import get_document_by_id
        doc = get_document_by_id(document_id)
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        return DocumentMetadata(document_id=doc.document_id, file_name=doc.file_name, blob_url=doc.blob_url, uploaded_by=doc.uploaded_by, upload_date=doc.upload_date.isoformat(), file_type=doc.file_type)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@app.get("/documents/{document_id}/download")
def download_document(document_id: int):
    try:
        from database import get_document_by_id
        from blob import download_blob
        doc = get_document_by_id(document_id)
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        content = download_blob(doc.blob_url)
        if isinstance(content, bytes):
            return Response(content=content, media_type="application/octet-stream")
        return FileResponse(path=str(content), filename=doc.file_name, media_type="application/octet-stream")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@app.post("/documents/{document_id}/share", response_model=ShareLinkResponse)
def generate_share_link(document_id: int, request: ShareLinkRequest):
    try:
        from database import get_document_by_id
        from blob import generate_sas_url
        doc = get_document_by_id(document_id)
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        if request.expiry_hours <= 0:
            raise HTTPException(status_code=400, detail="Expiry hours must be positive")
        sas_url = generate_sas_url(doc.blob_url, expiry_hours=request.expiry_hours, document_id=doc.document_id)
        return ShareLinkResponse(document_id=doc.document_id, sas_url=sas_url, expires_in_hours=request.expiry_hours)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@app.delete("/documents/{document_id}")
def delete_document(document_id: int):
    try:
        from database import delete_document_by_id, get_document_by_id
        from blob import delete_blob
        doc = get_document_by_id(document_id)
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        try:
            delete_blob(doc.blob_url)
        except Exception:
            pass
        delete_document_by_id(document_id)
        return {"message": "Document deleted successfully"}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

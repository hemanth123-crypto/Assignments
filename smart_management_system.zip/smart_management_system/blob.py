import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote

from dotenv import load_dotenv

try:
    from azure.storage.blob import BlobServiceClient, BlobSasPermissions, generate_blob_sas
except Exception:  # pragma: no cover - optional dependency in some environments
    BlobServiceClient = None
    BlobSasPermissions = None
    generate_blob_sas = None

load_dotenv()

CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_CONTAINER_NAME", "documents")
UPLOAD_ROOT = Path(__file__).resolve().parent / "uploads"
UPLOAD_ROOT.mkdir(exist_ok=True)

if CONNECTION_STRING and BlobServiceClient:
    blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
else:
    blob_service_client = None


def upload_blob(container_name: str, blob_name: str, data: bytes, content_type: str = "application/octet-stream") -> str:
    safe_name = blob_name.replace("/", "__")
    target_path = UPLOAD_ROOT / safe_name
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_bytes(data)

    if blob_service_client:
        try:
            container = blob_service_client.get_container_client(container_name)
            try:
                container.get_container_properties()
            except Exception:
                container.create_container()
            container.upload_blob(name=blob_name, data=data, content_type=content_type, overwrite=True)
        except Exception:
            pass

    return str(target_path)


def get_blob_url(container_name: str, blob_name: str) -> str:
    if not blob_service_client:
        return str(UPLOAD_ROOT / blob_name.replace("/", "__"))
    return blob_service_client.get_blob_client(container_name, blob_name).url


def download_blob(blob_url: str):
    local_path = Path(str(blob_url))
    if local_path.exists():
        return local_path.read_bytes()

    if not blob_service_client:
        if blob_url.startswith("http"):
            return blob_url.encode("utf-8")
        return str(blob_url)

    try:
        parsed = blob_service_client.get_blob_client_from_url(blob_url)
        downloader = parsed.download_blob()
        return downloader.readall()
    except Exception:
        return b""


def generate_sas_url(blob_url: str, expiry_hours: int = 1, document_id: int | None = None) -> str:
    if not blob_service_client:
        expiry = datetime.now(timezone.utc) + timedelta(hours=expiry_hours)
        if document_id is None:
            document_id = "document"
        return f"http://127.0.0.1:8000/documents/{document_id}/download?expires={int(expiry.timestamp())}&token=local"

    try:
        blob_client = blob_service_client.get_blob_client_from_url(blob_url)
        expiry_time = datetime.now(timezone.utc) + timedelta(hours=expiry_hours)
        sas_token = generate_blob_sas(
            account_name=blob_client.account_name,
            container_name=blob_client.container_name,
            blob_name=blob_client.blob_name,
            account_key=blob_service_client.credential.account_key,
            permission=BlobSasPermissions(read=True),
            expiry=expiry_time,
        )
        return f"{blob_client.url}?{sas_token}"
    except Exception:
        expiry = datetime.now(timezone.utc) + timedelta(hours=expiry_hours)
        if document_id is None:
            document_id = "document"
        return f"http://127.0.0.1:8000/documents/{document_id}/download?expires={int(expiry.timestamp())}&token=local"


def delete_blob(blob_url: str) -> None:
    if not blob_service_client:
        local_path = Path(str(blob_url))
        if local_path.exists():
            local_path.unlink()
        return

    blob_client = blob_service_client.get_blob_client_from_url(blob_url)
    blob_client.delete_blob()

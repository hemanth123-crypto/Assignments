from fastapi.testclient import TestClient

from app import app

client = TestClient(app)


def test_upload_list_download_and_delete_document():
    response = client.post(
        "/documents/upload",
        files={"file": ("sample.txt", b"hello azure", "text/plain")},
        data={"uploaded_by": "tester"},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    document_id = payload["document_id"]

    list_response = client.get("/documents")
    assert list_response.status_code == 200
    assert any(item["document_id"] == document_id for item in list_response.json())

    download_response = client.get(f"/documents/{document_id}/download")
    assert download_response.status_code == 200
    assert download_response.content == b"hello azure"

    share_response = client.post(f"/documents/{document_id}/share", json={"expiry_hours": 1})
    assert share_response.status_code == 200
    assert "http" in share_response.json()["sas_url"] or "file" in share_response.json()["sas_url"]

    delete_response = client.delete(f"/documents/{document_id}")
    assert delete_response.status_code == 200
    assert delete_response.json()["message"] == "Document deleted successfully"
